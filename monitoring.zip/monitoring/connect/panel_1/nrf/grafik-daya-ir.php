<?php
	//buat koneksi ke database
	$koneksi = mysqli_connect("localhost", "root", "", "dbmonitoring");

	//membaca informasi tanggal pada database sumbu x
	$tanggal = mysqli_query($koneksi, "SELECT tanggal FROM tb_sensor ORDER BY id DESC LIMIT 3");

	// membaca informasi tegangan pada database sumbu y
	$lux = mysqli_query($koneksi, "SELECT lux FROM tb_sensor ORDER BY id DESC");


?>

<!-- TAMPILAN GRAFIK -->
<div class="panel panel-primary">
	<div class="panel-heading"></div>
</div>

<div class="panel-body">
	<canvas id="panel1_nrf_dayaIr"></canvas>

	<!-- gambar grafik -->
	<script type="text/javascript">
		//baca is canvas
		var dayaIr = document.getElementById('panel1_nrf_dayaIr');
		//letakkan data tanggal dan suhu untuk grafik
		var data_ir = {
			labels : [
			<?php 
				while ($data_tanggal = mysqli_fetch_array($tanggal)) {
					echo '"'.$data_tanggal['tanggal'].'",';
				}
			?>
			],
			datasets : [
			  {
				label : "Iradiasi",
				fill : true, 
				backgroundColor: "rgba(78, 115, 223, 0.05)",
				borderColor : "rgba(255, 127, 0, 1)",
				lineTension : 0.1,
				data : [
					<?php
						while ($data_lux = mysqli_fetch_array($lux)) 
							{
								echo $data_lux['lux']. ',' ;
							}	

					?>
				]
			  }
			]
		};

		//option grafik
		var option1 = {
			showLines : true,
			animation : {
				duration : 1
			}
		};

		//cetak grafik dalam kanvas
		var DayaIr = Chart.Line(dayaIr, {
			data : data_ir,
			options : option
		});

	</script>
</div>