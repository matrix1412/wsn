<?php
include "config.php";


if(isset($_POST['btn_submit'])){

    $uname = mysqli_real_escape_string($con,$_POST['form_user']);
    $password = mysqli_real_escape_string($con,$_POST['form_pwd']);


    if ($uname != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from users where username='".$uname."' and password='".$password."'";
        $result = mysqli_query($con, $sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['uname'] = $uname;
            header('Location: ../index.php');
        }else{
             echo '<script type="text/javascript"> alert("Username dan Password Salah !"); </script>';
        }

    }

}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Custom fonts for this template-->
    <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

</head>

<body class="bg-gradient-secondary">

<div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Monitoring Solar Panel</h1>
                                    </div>
                                    <form class="user" method="post" onsubmit="return validasi()">
                                        <div class="form-group">
                                             <input type="text" class="textbox form-control form-control-user" id="form_user" name="form_user" placeholder="Username" />
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="textbox form-control form-control-user" id="form_pwd" name="form_pwd" placeholder="Password"/>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember
                                                    Me</label>
                                            </div>
                                        </div>
                                        <input type="submit" value="Login" name="btn_submit" id="btn_submit" class="btn btn-primary btn-block" />
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.php">Forgot Password?</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <script type="text/javascript">
    function validasi() {
        var username = document.getElementById("form_user").value;
        var password = document.getElementById("form_pwd").value;       
        if (username != "" && password!="") {
            return true;
        }else{
            alert('Username dan Password tidak boleh kosong. !');
            return false;
        }
    }
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="../dist/vendor/jquery/jquery.min.js"></script>
    <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../dist/js/sb-admin-2.min.js"></script>

</body>

</html>